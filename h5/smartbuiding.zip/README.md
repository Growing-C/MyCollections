### 安装

```
npm install
```

### 运行&发布

```
npm run start

npm run build
```

### 代码结构

```
├── mock
├── public
└── src
    ├── assets
    ├── components
    ├── layouts
    ├── models
    ├── pages
    ├── services
    └── utils
```
