import React from 'react';
import { Router as DefaultRouter, Route, Switch } from 'react-router-dom';
import dynamic from 'umi/dynamic';
import renderRoutes from 'umi/_renderRoutes';
import RendererWrapper0 from 'E:/android workspace/wechatapp/BCLLockWechat/smartbuiding/src/pages/.umi/LocaleWrapper.jsx'
import _dvaDynamic from 'dva/dynamic'

let Router = require('dva/router').routerRedux.ConnectedRouter;

let routes = [
  {
    "path": "/",
    "component": _dvaDynamic({
  
  component: () => import(/* webpackChunkName: "layouts__index" */'../../layouts/index.js'),
  
}),
    "routes": [
      {
        "path": "/home",
        "exact": true,
        "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import(/* webpackChunkName: 'p__home__models__index.js' */'E:/android workspace/wechatapp/BCLLockWechat/smartbuiding/src/pages/home/models/index.js').then(m => { return { namespace: 'index',...m.default}})
],
  component: () => import(/* webpackChunkName: "p__home__index" */'../home/index.js'),
  
}),
        "_title": "test",
        "_title_default": "test"
      },
      {
        "path": "/",
        "exact": true,
        "component": _dvaDynamic({
  
  component: () => import(/* webpackChunkName: "p__index" */'../index.js'),
  
}),
        "_title": "test",
        "_title_default": "test"
      },
      {
        "path": "/user/component/tab0",
        "exact": true,
        "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import(/* webpackChunkName: 'p__user__models__index.js' */'E:/android workspace/wechatapp/BCLLockWechat/smartbuiding/src/pages/user/models/index.js').then(m => { return { namespace: 'index',...m.default}})
],
  component: () => import(/* webpackChunkName: "p__user__component__tab0" */'../user/component/tab0.js'),
  
}),
        "_title": "test",
        "_title_default": "test"
      },
      {
        "path": "/user/component/tab1",
        "exact": true,
        "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import(/* webpackChunkName: 'p__user__models__index.js' */'E:/android workspace/wechatapp/BCLLockWechat/smartbuiding/src/pages/user/models/index.js').then(m => { return { namespace: 'index',...m.default}})
],
  component: () => import(/* webpackChunkName: "p__user__component__tab1" */'../user/component/tab1.js'),
  
}),
        "_title": "test",
        "_title_default": "test"
      },
      {
        "path": "/user/component/tab2",
        "exact": true,
        "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import(/* webpackChunkName: 'p__user__models__index.js' */'E:/android workspace/wechatapp/BCLLockWechat/smartbuiding/src/pages/user/models/index.js').then(m => { return { namespace: 'index',...m.default}})
],
  component: () => import(/* webpackChunkName: "p__user__component__tab2" */'../user/component/tab2.js'),
  
}),
        "_title": "test",
        "_title_default": "test"
      },
      {
        "path": "/user",
        "exact": true,
        "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import(/* webpackChunkName: 'p__user__models__index.js' */'E:/android workspace/wechatapp/BCLLockWechat/smartbuiding/src/pages/user/models/index.js').then(m => { return { namespace: 'index',...m.default}})
],
  component: () => import(/* webpackChunkName: "p__user__index" */'../user/index.js'),
  
}),
        "_title": "test",
        "_title_default": "test"
      },
      {
        "component": () => React.createElement(require('E:/android workspace/wechatapp/BCLLockWechat/smartbuiding/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: false }),
        "_title": "test",
        "_title_default": "test"
      }
    ],
    "_title": "test",
    "_title_default": "test"
  },
  {
    "component": () => React.createElement(require('E:/android workspace/wechatapp/BCLLockWechat/smartbuiding/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: false }),
    "_title": "test",
    "_title_default": "test"
  }
];
window.g_routes = routes;
window.g_plugins.applyForEach('patchRoutes', { initialValue: routes });

// route change handler
function routeChangeHandler(location, action) {
  window.g_plugins.applyForEach('onRouteChange', {
    initialValue: {
      routes,
      location,
      action,
    },
  });
}
window.g_history.listen(routeChangeHandler);
routeChangeHandler(window.g_history.location);

export default function RouterWrapper() {
  return (
<RendererWrapper0>
          <Router history={window.g_history}>
      { renderRoutes(routes, {}) }
    </Router>
        </RendererWrapper0>
  );
}
