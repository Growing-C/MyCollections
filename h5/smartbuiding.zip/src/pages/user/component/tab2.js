import React, { Fragment } from 'react';
import { connect } from 'dva';
import styles from '../index.css';

import { TabBar } from 'antd-mobile';
import { Flex } from 'antd-mobile';
import { ListView } from 'antd-mobile';
import { Item } from 'antd-mobile';
import { List } from 'antd-mobile';
import { Picker } from 'antd-mobile';
import { Button } from 'antd-mobile';
import header from '../../../images/header.png';

class Tab2Item extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      user: {}
    };
  }

  componentDidMount() {
    var user = localStorage.getItem('user');
    if (user) {
      console.log(user);
      var item = JSON.parse(user);
      console.log(item.name);
      this.setState({
        user: item
      });
    }
  }

  //退出登录
  logOut = () => {
    localStorage.removeItem('acckey');
    localStorage.removeItem('acctoken');
    this.props.dispatch({
      type: 'user/logOut2Home'
    });
  };

  //   <div className={styles.div9}>
  //   <i className={`${styles.icon10} iconfont icon-huanyuanhuabu`} />
  //   <span className={styles.span11}> </span>
  // </div>
  /**
   * 渲染
   */
  render() {
    const { dispatch } = this.props;
    return (
      <div>
        <div className={styles.divUserHeader}>
          <img
            className={styles.image}
            src={header}
            alt=""
          />

          <div className={styles.right}>{this.state.user.name}</div>
        </div>
        <div className={styles.divider} />

        <div className={styles.userInfo}>
          <Flex>
            <Flex.Item className={styles.flexitem15}>
              <div className={styles.currentHint}>当前绑定手机</div>
              <div className={styles.currentPhone}>{this.state.user.phone}</div>
            </Flex.Item>
            <Flex.Item className={styles.flexitem15}>
              <div>
                <span className={styles.changeBind}>更改绑定</span>

                <i
                  className={`${
                    styles.userInfoChange
                  } iconfont icon-youjiantou`}
                />
              </div>
            </Flex.Item>
          </Flex>
        </div>

        <Button
          className={styles.buttonLogOut}
          onClick={this.logOut}
          type="primary"
        >
          退出登录
        </Button>
      </div>
    );
  }
}

function mapStateToProps({ user }) {
  return Object.assign({}, user);
}

export default connect(mapStateToProps)(Tab2Item);
