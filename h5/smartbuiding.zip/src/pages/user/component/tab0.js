import React, { Fragment } from 'react';
import { connect } from 'dva';
import styles from '../index.css';

import { TabBar } from 'antd-mobile';
import { Flex, PullToRefresh } from 'antd-mobile';
import { ListView } from 'antd-mobile';
import { Item } from 'antd-mobile';
import { List } from 'antd-mobile';
import { Picker } from 'antd-mobile';
import Alert from 'components/alert/alert';
import Toast from 'components/alert/Toast';
import { Grid } from 'antd-mobile';
import isEmpty from 'lodash/isEmpty';

import ReactDOM from 'react-dom';
import ReactSwipe from 'react-swipe';

// generate slide panes
const numberOfSlides = 10;

// change Swipe.js options by query params
// const startSlide = parseInt(query.startSlide, 10) || 0;

let reactSwipeEl;
let ref;
class Tab0Item extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      refreshing: false,
      height: document.documentElement.clientHeight,
      selectedOrderIndex: 0, //选中订单的脚标
      orderList: [], //订单列表
      deviceList: [], //选中订单的设备列表
      selectedDevice: {} //选中设备
    };
    ref = this;
  }

  componentDidMount() {
    this.getOrderList();
  }
  //假装有数据
  mockData() {
    let mockOrderList = [];
    mockOrderList.push({
      address: '地址地址',
      roomName: '房间房间   1',
      buildingName: '大厦1',
      deviceList: [
        { deviceId: '1', deviceName: '1 房间1' },
        { deviceId: '2', deviceName: '1 房间2' },
        { deviceId: '3', deviceName: '1 房间2' },
        { deviceId: '4', deviceName: '1 房间2' }
      ]
    });
    mockOrderList.push({
      roomName: '房间房间   1',
      buildingName: '大厦1',
      deviceList: [{ deviceName: '2 海景房1' }, { deviceName: '2 海景房2' }]
    });
    mockOrderList.push({
      roomName: '房间房间   1',
      buildingName: '大厦1',
      deviceList: [{ deviceName: '3 别墅大门1' }, { deviceName: '3 别墅后门2' }]
    });
    mockOrderList.push({
      roomName: '房间房间   1',
      buildingName: '大厦1',
      deviceList: [{ deviceName: '4 厨房1' }, { deviceName: '4 厨房2' }]
    });
    this.setState({
      orderList: mockOrderList,
      deviceList: mockOrderList[this.state.selectedOrderIndex].deviceList,
      selectedDevice: mockOrderList[this.state.selectedOrderIndex].deviceList[0]
    });
  }

  //获取订单列表
  getOrderList = () => {
    console.log('getOrderList');

    this.props.dispatch({
      type: 'user/fetchOrderList', // 这里就会触发models层里面effects中fetchVerifyCode方法（也可以直接触发reducer中方法，看具体情况） ,home就是models里的命名空间名字

      callback: res => {
        if (res) {
          // console.log(res); // 请求完成后返回的结果

          // let order = { name: '222', deviceId: '222' };
          if (res[0]) this.getOrderDetail(res[0]);
          this.setState({
            orderList: res
          });

          // this.mockData();
        }
        
        this.setState({ refreshing: false });
      },
      fail: res => {
        console.log(`getOrderList fail ${res}`);
        
        this.setState({ refreshing: false });
        // this.mockData();
      }
    });
  };

  //获取订单详情
  getOrderDetail = data => {
    console.log('getOrderDetail');
    console.log(data.buildingName); // 请求完成后返回的结果
    console.log(data.address); // 请求完成后返回的结果

    this.props.dispatch({
      type: 'user/fetchOrderDetail',
      payload: {
        orderId: data.orderId
      },
      callback: res => {
        if (res) {
          // console.log(res);
          // console.log(res.orderId);

          this.setState({
            deviceList: res.deviceList
          });
          this.selectDeviceItem(0);
        }
      }
    });
  };
  //点击开锁
  clickOpenLock = () => {
    if (!this.state.selectedDevice) {
      Toast.failToast('没有选中设备');
      return;
    }
    console.log('onClickOpenLock');
    console.log(this.state.selectedDevice.deviceId);
    if (
      !this.state.selectedDevice.deviceId ||
      isEmpty(this.state.selectedDevice.deviceId)
    ) {
      //没有设备
      Toast.failToast('暂未选择设备');
      return;
    }

    this.props.dispatch({
      type: 'user/requestUnlock',
      payload: {
        deviceId: this.state.selectedDevice.deviceId,
        orderNo: this.state.orderList[this.state.selectedOrderIndex].orderId
      }
    });
  };

  //选择item
  selectDeviceItem = index => {
    console.log(`select device ${index}`);
    this.setState({
      selectedDevice: this.state.deviceList[index]
    });
  };

  //选择上一个订单
  clickNextOrder = () => {
    if (this.state.selectedOrderIndex == this.state.orderList.length - 1) {
      //最后一个
      Toast.showToast('最后一个了');
    } else {
      reactSwipeEl.next();
    }
  };
  //选择下一个订单
  clickLastOrder = () => {
    if (this.state.selectedOrderIndex == 0) {
      //最后一个
      Toast.showToast('第一个了');
    } else {
      reactSwipeEl.prev();
    }
  };

  //选中某一个订单
  selectOrder = index => {
    console.log(`select order ${index}`);
    this.setState({
      selectedOrderIndex: index
    });
    this.getOrderDetail(this.state.orderList[index]);
  };

  /**
   * 渲染
   */
  render() {
    const { dispatch } = this.props;
    const orderSize = this.state.orderList.length;
    let paneNodes;
    if (orderSize && orderSize > 0) {
      //存在订单 且长度不为0
      paneNodes = Array.apply(null, Array(orderSize)).map((_, i) => {
        return (
          <div key={i}>
            <div className={styles.div9}>
              <span className={styles.span11}>
                {this.state.orderList[i].address}
              </span>
              <span className={styles.span11}>
                {this.state.orderList[i].roomName}
              </span>
            </div>
            <Flex className={styles.flex12}>
              <div onClick={this.clickLastOrder}>
                <i className={`${styles.icon14} iconfont icon-ico_leftarrow`} />
              </div>
              <Flex.Item className={styles.flexitem15}>
                <div className={styles.div16} onClick={this.clickOpenLock}>
                  <i className={`${styles.icon17} iconfont icon-suo`} />
                </div>
              </Flex.Item>
              <div onClick={this.clickNextOrder}>
                <i className={`${styles.icon19} iconfont icon-youjiantou`} />
              </div>
            </Flex>

            <Flex>
              <Flex.Item
                className={styles.bottomselect}
                onClick={() => this.selectDeviceItem(0)}
              >
                <div>
                  {!this.state.deviceList[0] ? (
                    <span />
                  ) : (
                    <i
                      className={`${
                        this.state.selectedDevice.deviceId ==
                        this.state.deviceList[0].deviceId
                          ? styles.iconBottomSelected
                          : styles.iconBottom
                      } iconfont icon-suo`}
                    />
                  )}
                </div>
                <div>
                  {!this.state.deviceList[0] ? (
                    <span />
                  ) : (
                    <span
                      className={
                        this.state.selectedDevice.deviceId ==
                        this.state.deviceList[0].deviceId
                          ? styles.bottomTextSelected
                          : styles.bottomText
                      }
                    >{`${this.state.deviceList[0].deviceName}`}</span>
                  )}
                </div>
              </Flex.Item>
              <Flex.Item
                className={styles.bottomselect}
                onClick={() => this.selectDeviceItem(1)}
              >
                <div>
                  {!this.state.deviceList[1] ? (
                    <span />
                  ) : (
                    <i
                      className={`${
                        this.state.selectedDevice.deviceId ==
                        this.state.deviceList[1].deviceId
                          ? styles.iconBottomSelected
                          : styles.iconBottom
                      } iconfont icon-suo`}
                    />
                  )}
                </div>
                <div>
                  {!this.state.deviceList[1] ? (
                    <span />
                  ) : (
                    <span
                      className={
                        this.state.selectedDevice.deviceId ==
                        this.state.deviceList[1].deviceId
                          ? styles.bottomTextSelected
                          : styles.bottomText
                      }
                    >{`${this.state.deviceList[1].deviceName}`}</span>
                  )}
                </div>
              </Flex.Item>
              <Flex.Item
                className={styles.bottomselect}
                onClick={() => this.selectDeviceItem(2)}
              >
                <div>
                  {!this.state.deviceList[2] ? (
                    <span />
                  ) : (
                    <i
                      className={`${
                        this.state.selectedDevice.deviceId ==
                        this.state.deviceList[2].deviceId
                          ? styles.iconBottomSelected
                          : styles.iconBottom
                      } iconfont icon-suo`}
                    />
                  )}
                </div>
                <div>
                  {!this.state.deviceList[2] ? (
                    <span />
                  ) : (
                    <span
                      className={
                        this.state.selectedDevice.deviceId ==
                        this.state.deviceList[2].deviceId
                          ? styles.bottomTextSelected
                          : styles.bottomText
                      }
                    >{`${this.state.deviceList[2].deviceName}`}</span>
                  )}
                </div>
              </Flex.Item>
              <Flex.Item
                className={styles.bottomselect}
                onClick={() => this.selectDeviceItem(3)}
              >
                <div>
                  {!this.state.deviceList[3] ? (
                    <span />
                  ) : (
                    <i
                      className={`${
                        this.state.selectedDevice.deviceId ==
                        this.state.deviceList[3].deviceId
                          ? styles.iconBottomSelected
                          : styles.iconBottom
                      } iconfont icon-suo`}
                    />
                  )}
                </div>
                <div>
                  {!this.state.deviceList[3] ? (
                    <span />
                  ) : (
                    <span
                      className={
                        this.state.selectedDevice.deviceId ==
                        this.state.deviceList[3].deviceId
                          ? styles.bottomTextSelected
                          : styles.bottomText
                      }
                    >{`${this.state.deviceList[3].deviceName}`}</span>
                  )}
                </div>
              </Flex.Item>
            </Flex>
          </div>
        );
      });
    } else {
      paneNodes = (
        <div key="0" className={styles.nodata}>
          暂无订单
        </div>
      );
    }

    const swipeOptions = {
      startSlide: this.state.selectedOrderIndex,
      auto: 0,
      speed: 300,
      disableScroll: false,
      continuous: false,
      widthOfSiblingSlidePreview: 0,
      callback() {
        console.log('slide changed');
      },
      transitionEnd() {
        console.log('ended transition');
        console.log(reactSwipeEl.getPos());
        ref.selectOrder(reactSwipeEl.getPos());
      }
    };
    return (
      <div>
        <PullToRefresh
          damping={60}
          ref={el => (this.ptr = el)}
          style={{
            height: this.state.height,
            overflow: 'auto'
          }}
          indicator={{ deactivate: '上拉可以刷新' }}
          direction={'down'}
          refreshing={this.state.refreshing}
          onRefresh={() => {
            this.setState({ refreshing: true });
            this.getOrderList()
            // setTimeout(() => {
            //   this.setState({ refreshing: false });
            // }, 1000);
          }}
        >
          {
            <ReactSwipe
              className="mySwipe"
              swipeOptions={swipeOptions}
              ref={el => (reactSwipeEl = el)}
            >
              {paneNodes}
            </ReactSwipe>
          }
        </PullToRefresh>
      </div>
    );
  }
}

// {this.state.orderList.map(i => (
//   <div key={i} style={{ textAlign: 'center', padding: 20 }}>
//     {'pull down'} {i}
//   </div>
// ))}
function mapStateToProps({ user }) {
  return Object.assign({}, user);
}

export default connect(mapStateToProps)(Tab0Item);
/* <div>
        <div className={styles.div9}>
          <span className={styles.span11}>
            {this.state.selectedDevice.deviceName}
          </span>
        </div>
        <Flex className={styles.flex12}>
          <div className={styles.div13}>
            <i className={`${styles.icon14} iconfont icon-ico_leftarrow`} />
          </div>
          <Flex.Item className={styles.flexitem15}>
            <div className={styles.div16} onClick={this.clickOpenLock}>
              <i className={`${styles.icon17} iconfont icon-suo`} />
            </div>
          </Flex.Item>
          <div className={styles.div18}>
            <i className={`${styles.icon19} iconfont icon-youjiantou`} />
          </div>
        </Flex>

        <Flex>
          <Flex.Item
            className={styles.bottomselect}
            onClick={() => this.selectItem(0)}
          >
            <div>
              {!this.state.deviceList[0] ? (
                <span />
              ) : (
                <i className={`${styles.iconBottom} iconfont icon-suo`} />
              )}
            </div>
            <div>
              {!this.state.deviceList[0] ? (
                <span />
              ) : (
                <span className={styles.bottomText}>{`${
                  this.state.deviceList[0].deviceName
                }`}</span>
              )}
            </div>
          </Flex.Item>
          <Flex.Item
            className={styles.bottomselect}
            onClick={() => this.selectItem(1)}
          >
            <div>
              {!this.state.deviceList[1] ? (
                <span />
              ) : (
                <i className={`${styles.iconBottom} iconfont icon-suo`} />
              )}
            </div>
            <div>
              {!this.state.deviceList[1] ? (
                <span />
              ) : (
                <span className={styles.bottomText}>{`${
                  this.state.deviceList[1].deviceName
                }`}</span>
              )}
            </div>
          </Flex.Item>
          <Flex.Item
            className={styles.bottomselect}
            onClick={() => this.selectItem(2)}
          >
            <div>
              {!this.state.deviceList[2] ? (
                <span />
              ) : (
                <i className={`${styles.iconBottom} iconfont icon-suo`} />
              )}
            </div>
            <div>
              {!this.state.deviceList[2] ? (
                <span />
              ) : (
                <span className={styles.bottomText}>{`${
                  this.state.deviceList[2].deviceName
                }`}</span>
              )}
            </div>
          </Flex.Item>
          <Flex.Item
            className={styles.bottomselect}
            onClick={() => this.selectItem(3)}
          >
            <div>
              {!this.state.deviceList[3] ? (
                <span />
              ) : (
                <i className={`${styles.iconBottom} iconfont icon-suo`} />
              )}
            </div>
            <div>
              {!this.state.deviceList[3] ? (
                <span />
              ) : (
                <span className={styles.bottomText}>{`${
                  this.state.deviceList[3].deviceName
                }`}</span>
              )}
            </div>
          </Flex.Item>
        </Flex>
      </div> */
