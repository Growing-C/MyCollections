import React, { Fragment } from 'react';
import { connect } from 'dva';
import styles from '../index.css';

import { TabBar } from 'antd-mobile';
import { Flex, PullToRefresh } from 'antd-mobile';
import { ListView } from 'antd-mobile';
import { Item } from 'antd-mobile';
import { List } from 'antd-mobile';
import { Picker } from 'antd-mobile';
import { getFormatDate } from 'utils/index';

//----------------------------------------------------------------------

function MyBody(props) {
  return (
    <div className="am-list-body my-body">
      <span style={{ display: 'none' }}>you can custom body wrap element</span>
      {props.children}
    </div>
  );
}

// const data = [
//   {
//     img: 'https://zos.alipayobjects.com/rmsportal/dKbkpPXKfvZzWCM.png',
//     title: '长风公寓 1001室 主卧',
//     des: '180元/天'
//   },
//   {
//     img: 'https://zos.alipayobjects.com/rmsportal/XmwCzSeJiqpkuMB.png',
//     title: '长风公寓 1001室 主卧',
//     des: '180元/天'
//   },
//   {
//     img: 'https://zos.alipayobjects.com/rmsportal/hfVtzEhPzTUewPm.png',
//     title: '长风公寓 1001室 主卧',
//     des: '180元/天'
//   }
// ];
const NUM_SECTIONS = 1; //目前是一个单一的列表，所以部分只有一个
const NUM_ROWS_PER_SECTION = 5; //每个部分里面有几条数据
let pageIndex = 0;

const dataBlobs = {};
let sectionIDs = []; //每一个部分的 id
let rowIDs = []; //每一个部分中的某一条数据的id
//获取数据
function genData(pIndex = 0) {
  for (let i = 0; i < NUM_SECTIONS; i++) {
    const ii = pIndex * NUM_SECTIONS + i;
    const sectionName = `Section ${ii}`;
    sectionIDs.push(sectionName);
    dataBlobs[sectionName] = sectionName;
    rowIDs[ii] = [];

    for (let jj = 0; jj < NUM_ROWS_PER_SECTION; jj++) {
      const rowName = `S${ii}, R${jj}`;
      rowIDs[ii].push(rowName);
      dataBlobs[rowName] = rowName;
    }
  }
  sectionIDs = [...sectionIDs];
  rowIDs = [...rowIDs];
}

//-----------------------------------------------------------------------
class Tab1Item extends React.PureComponent {
  constructor(props) {
    super(props);
    const getSectionData = (dataBlob, sectionID) => dataBlob[sectionID];
    const getRowData = (dataBlob, sectionID, rowID) => dataBlob[rowID];

    const dataSource = new ListView.DataSource({
      getRowData,
      getSectionHeaderData: getSectionData,
      rowHasChanged: (row1, row2) => row1 !== row2,
      sectionHeaderHasChanged: (s1, s2) => s1 !== s2
    });

    this.state = {
      refreshing: false,
      height: document.documentElement.clientHeight,
      dataSource,
      isLoading: true,
      height: (document.documentElement.clientHeight * 3) / 4
    };
  }

  //假装有数据
  mockData() {
    console.log(getFormatDate(new Date(1552963272000)));
    let mockOrderList = [];
    mockOrderList.push({
      roomName: '房间房间 房间 房间 房间 房间  1',
      buildingName: '大厦1',
      statusName: 'check in',
      reserveStartTime: 1542163272000,
      reserveEndTime: 1552963272000,
      price: 10
    });
    mockOrderList.push({
      roomName: '房间1',
      buildingName: '大厦1',
      statusName: 'check in',
      reserveStartTime: 1542163272000,
      reserveEndTime: 1552963272000,
      price: 10
    });
    mockOrderList.push({
      roomName: '房间1',
      buildingName: '大厦1',
      statusName: 'check in',
      reserveStartTime: 1542163272000,
      reserveEndTime: 1552963272000,
      price: 10
    });
    mockOrderList.push({
      roomName: '房间1',
      buildingName: '大厦1',
      statusName: 'check in',
      reserveStartTime: 1542163272000,
      reserveEndTime: 1552963272000,
      price: 10
    });
    return mockOrderList;
  }

  componentDidMount() {
    // you can scroll to the specified position
    // setTimeout(() => this.lv.scrollTo(0, 120), 800);

    // const hei = document.documentElement.clientHeight - ReactDOM.findDOMNode(this.lv).parentNode.offsetTop;
    const hei = document.documentElement.clientHeight - 1;
    // simulate initial Ajax
    // setTimeout(() => {
    //   genData();
    //   this.setState({
    //     dataSource: this.state.dataSource.cloneWithRowsAndSections(
    //       dataBlobs,
    //       sectionIDs,
    //       rowIDs
    //     ),
    //     isLoading: false,
    //     height: hei
    //   });
    // }, 500);
    this.getOrderList();
  }

  //获取订单列表
  getOrderList = () => {
    console.log('订单列表 getOrderList');

    // this.setDataFromOderList(this.mockData());
    this.props.dispatch({
      type: 'user/fetchOrderList',
      callback: res => {
        if (res) {
          // console.log(res); // 请求完成后返回的结果
          //
          // this.setState({
          //   orderList: res
          // });
          this.setDataFromOderList(res);
        }
        
        this.setState({ refreshing: false });
      },
      fail: res => {
        console.log(`getOrderList fail ${res}`);
        // this.mockData();
        
        this.setState({ refreshing: false });
      }
    });
  };

  //请求成功 获取到orderList之后 设置list界面数据
  setDataFromOderList = orderList => {
    if (orderList && orderList.length > 0) {
      let orderSize = orderList.length;
      console.log(`setDataFromOderList order size ${orderSize}`);

      for (let i = 0; i < NUM_SECTIONS; i++) {
        const ii = 0 * NUM_SECTIONS + i;
        const sectionName = `Section ${ii}`;
        sectionIDs.push(sectionName);
        dataBlobs[sectionName] = sectionName;
        rowIDs[ii] = [];

        for (let jj = 0; jj < orderSize; jj++) {
          const rowName = `S${ii}, R${jj}`;
          rowIDs[ii].push(rowName);
          dataBlobs[rowName] = orderList[jj];
        }
      }
      sectionIDs = [...sectionIDs];
      rowIDs = [...rowIDs];

      console.log(dataBlobs);
    }
    const hei = document.documentElement.clientHeight - 1;
    this.setState({
      dataSource: this.state.dataSource.cloneWithRowsAndSections(
        dataBlobs,
        sectionIDs,
        rowIDs
      ),
      isLoading: false,
      height: hei
    });
  };

  // If you use redux, the data maybe at props, you need use `componentWillReceiveProps`
  // componentWillReceiveProps(nextProps) {
  //   if (nextProps.dataSource !== this.props.dataSource) {
  //     this.setState({
  //       dataSource: this.state.dataSource.cloneWithRowsAndSections(nextProps.dataSource),
  //     });
  //   }
  // }

  onEndReached = event => {
    // load new data
    // hasMore: from backend data, indicates whether it is the last page, here is false
    if (this.state.isLoading && !this.state.hasMore) {
      return;
    }
    console.log('reach end', event);
    // this.setState({ isLoading: true });
    //TODO:加载更多list数据

    // setTimeout(() => {
    //   genData(++pageIndex);
    //   this.setState({
    //     dataSource: this.state.dataSource.cloneWithRowsAndSections(
    //       dataBlobs,
    //       sectionIDs,
    //       rowIDs
    //     ),
    //     isLoading: false
    //   });
    // }, 1000);
  };

  render() {
    const separator = (sectionID, rowID) => (
      <div
        key={`${sectionID}-${rowID}`}
        style={{
          backgroundColor: '#F5F5F9',
          height: 8,
          borderTop: '1px solid #ECECED',
          borderBottom: '1px solid #ECECED'
        }}
      />
    );
    // let index = data.length - 1;
    const row = (rowData, sectionID, rowID) => {
      // if (index < 0) {
      //   index = data.length - 1;
      // }
      // const obj = data[index--];
      console.log('rowData');
      console.log(rowData);
      return (
        <div key={rowID} style={{ padding: '0 15px' }}>
          <Flex
            style={{
              borderBottom: '1px solid #F6F6F6'
            }}
          >
            <div
              style={{
                lineHeight: '50px',
                color: '#888',
                fontSize: 15,
                width: '80%',
                overflow: 'hidden',
                textOverflow: 'ellipsis',
                whiteSpace: 'nowrap'
              }}
            >
              {`${rowData.buildingName}${rowData.roomName}`}
            </div>
            <Flex.Item>
              <div
                style={{
                  lineHeight: '50px',
                  color: '#1890ff',
                  fontSize: 12,
                  textAlign: 'right'
                }}
              >
                {rowData.statusName}
              </div>
            </Flex.Item>
          </Flex>

          <div
            style={{
              display: '-webkit-box',
              display: 'flex',
              padding: '15px 0'
            }}
          >
            <div style={{ lineHeight: 1 }}>
              <div style={{ marginBottom: '8px', fontWeight: 'bold' }}>
                {`${rowData.price}元/天`}
              </div>
              <div>
                <span style={{ fontSize: '10px', color: '#888' }}>
                  {`入住时间：${getFormatDate(
                    new Date(rowData.reserveStartTime)
                  )} 至 ${getFormatDate(new Date(rowData.reserveEndTime))}`}
                </span>
              </div>
            </div>
          </div>
        </div>
      );
    };

    //   <div
    //   style={{
    //     lineHeight: '50px',
    //     color: '#888',
    //     fontSize: 18,
    //     borderBottom: '1px solid #F6F6F6',
    //   }}
    // >{obj.title}</div>
    // <img style={{ height: '64px', marginRight: '15px' }} src={obj.img} alt="" />
    // renderSectionHeader={sectionData => (
    //   <div>{`Task ${sectionData.split(' ')[1]}`}</div>
    // )}

    // renderHeader={() => <span>header</span>}
    return (
      <PullToRefresh
        damping={60}
        ref={el => (this.ptr = el)}
        style={{
          height: this.state.height,
          overflow: 'auto'
        }}
        indicator={{ deactivate: '上拉可以刷新' }}
        direction={'down'}
        refreshing={this.state.refreshing}
        onRefresh={() => {
          this.setState({ refreshing: true });
          this.getOrderList(); 
        }}
      >
        {
          <ListView
            ref={el => (this.lv = el)}
            dataSource={this.state.dataSource}
            renderFooter={() => (
              <div style={{ padding: 30, textAlign: 'center' }}>
                {rowIDs.length > 0 ? (
                  <span>{this.state.isLoading ? 'Loading...' : 'Loaded'}</span>
                ) : (
                  <span>未查询到订单</span>
                )}
              </div>
            )}
            renderBodyComponent={() => <MyBody />}
            renderRow={row}
            renderSeparator={separator}
            style={{
              height: this.state.height,
              overflow: 'auto'
            }}
            pageSize={4}
            onScroll={() => {
              console.log('scroll');
            }}
            scrollRenderAheadDistance={500}
            onEndReached={this.onEndReached}
            onEndReachedThreshold={10}
          />
        }
      </PullToRefresh>
    );
  }
}

function mapStateToProps({ user }) {
  return Object.assign({}, user);
}

export default connect(mapStateToProps)(Tab1Item);
