import _ from 'lodash';
import { routerRedux } from 'dva/router';
import * as services from 'services';
import { queryParamWithHistory } from 'utils';

import Toast from 'components/alert/Toast';

export default {
  namespace: 'user',

  state: {},

  subscriptions: {
    setup({ dispatch, history }) {
      return history.listen(({ pathname }) => {
        if (pathname === '/user') {
          // console.log('111111111111111111')
          //  let aa= location.query
          //  console.log(aa)
          //  console.log(history)
        }
      });
    }
  },

  effects: {
    //获取订单列表
    *fetchOrderList({ payload, callback, fail }, { call, put, select }) {
      //fetchVerifyCode方法名，payload2是传来的参数，是个对象，如果没参数可以写成{_,{call,put,select}}
      const { data } = yield call(services.getOrderList, payload); // myService是引入service层那个js的一个名字，anum是后台要求传的参数，data就是后台返回来的数据
      console.log(data);
      if (data.code == '0') {
        callback(data.data);
      } else {
        fail(data.code);
        Toast.failToast(data.msg);
        if (data.code == 'E0000') {
          //没有登录的时候跳到登录页
          yield put({
            type: 'logOut2Home' 
          });
        }
      }
    },
    //获取订单详情
    *fetchOrderDetail({ payload, callback }, { call, put, select }) {
      const { data } = yield call(services.getOrderDetail, payload);
      console.log(data);
      if (data.code == '0') {
        callback(data.data);
      } else {
        Toast.failToast(data.msg);
      }
    },
    *requestUnlock({ payload }, { call, put, select }) {
      const { data } = yield call(services.openLock, payload);
      console.log(data);
      // console.log(data.code);
      if (data.code == '0') {
        Toast.successToast('开锁成功');
      } else {
        Toast.failToast(data.msg);
      }
    },

    *logOut2Home({ payload }, { put }) {
      yield put(
        routerRedux.push({
          pathname: '/home',
          query: payload
        })
      );
    },

    *updateState({ payload }, { call, put }) {
      console.log('updateState');
      for (let key in payload) {
        yield put({
          type: 'changeState',
          payload: {
            key: key,
            value: payload[key]
          }
        });
      }
    }
  },

  reducers: {
    changeState(state, { payload }) {
      return {
        ...state,
        [[payload.key]]: payload.value
      };
    }
  }
};
