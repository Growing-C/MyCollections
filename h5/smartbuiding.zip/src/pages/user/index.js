import React, { Fragment } from 'react';
import { connect } from 'dva';
import styles from './index.css';
import { TabBar } from 'antd-mobile';
import Tab0Item from './component/tab0';
import { Flex } from 'antd-mobile';
import Tab1Item from './component/tab1';
import { ListView } from 'antd-mobile';
import { Item } from 'antd-mobile';
import Tab2Item from './component/tab2';
import { List } from 'antd-mobile';
import { Picker } from 'antd-mobile';

class User extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {};
  }

  componentDidMount() {
    // this.getOrderList();
  }

  //获取订单列表
  getOrderList = () => {
    console.log('getOrderList');

    // var user = localStorage.getItem('user');
    // if (user) {
    //   console.log(user);
    //   var item = JSON.parse(user);
    //   console.log(item.name);
    // }
    this.props.dispatch({
      type: 'user/fetchOrderList', // 这里就会触发models层里面effects中fetchVerifyCode方法（也可以直接触发reducer中方法，看具体情况） ,home就是models里的命名空间名字
      payload: {
        // phone: '15999999999'
      },
      callback: (res) => {
        if (res) {
          console.log(res);// 请求完成后返回的结果
        }
      }
    });
  };

  /**
   * 渲染
   */
  render() {
    const separator = (sectionID, rowID) => (
      <div
        key={`${sectionID}-${rowID}`}
        style={{ backgroundColor: '#F5F5F9', height: 1 }}
      />
    );

    return (
      <TabBar
        className={styles.tabbar8}
        barTintColor="#"
        prerenderingSiblingsNumber={0}
      >
        <TabBar.Item
          icon={<i className="iconfont icon-lanya " />}
          selectedIcon={<i className="iconfont icon-lanya " />}
          title="首页"
          selected={
            this.state.selectedTab === 'tab0' || !this.state.selectedTab
          }
          onPress={() => {
            this.setState({
              selectedTab: 'tab0'
            });
          }}
        >
          <Tab0Item />
        </TabBar.Item>
        <TabBar.Item
          icon={<i className="iconfont icon-shiyongwendang " />}
          selectedIcon={<i className="iconfont icon-shiyongwendang " />}
          title="订单列表"
          selected={this.state.selectedTab === 'tab1'}
          onPress={() => {
            this.setState({
              selectedTab: 'tab1'
            });
          }}
        >
          <Tab1Item />
        </TabBar.Item>
        <TabBar.Item
          icon={<i className="iconfont icon-icon_zhanghao " />}
          selectedIcon={<i className="iconfont icon-icon_zhanghao " />}
          title="我的"
          selected={this.state.selectedTab === 'tab2'}
          onPress={() => {
            this.setState({
              selectedTab: 'tab2'
            });
          }}
        >
          <Tab2Item />
        </TabBar.Item>
      </TabBar>
    );
  }
}

function mapStateToProps({ user }) {
  return Object.assign({}, user);
}

export default connect(mapStateToProps)(User);
