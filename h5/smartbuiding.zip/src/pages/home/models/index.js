import _ from 'lodash';
import { routerRedux } from 'dva/router';
import * as services from 'services';
import { queryParamWithHistory } from "utils";

import Toast from "components/alert/Toast";


export default {

  namespace: 'home', //命名空间名字，必填  

  state: {test:1},//state就是用来放初始值的
// 订阅监听，比如我们监听路由，进入页面就如何，可以在这写
  subscriptions: {
    setup({dispatch, history}) {
      return history.listen(({pathname}) => {
        if (pathname === '/home') {

        }
      });
    },
  },

// 与后台交互，处理数据逻辑的地方
  effects: {
    * fetchVerifyCode({ payload }, {call, put, select }){//fetchVerifyCode方法名，payload2是传来的参数，是个对象，如果没参数可以写成{_,{call,put,select}}
        console.log('fetchVerifyCode start') 
         console.log(services) 
    　   const {data} = yield call(services.getCode, payload) // myService是引入service层那个js的一个名字，anum是后台要求传的参数，data就是后台返回来的数据
    　   console.log(data)
        // console.log(data.code) 
        if(data.code=='0'){
          Toast.successToast('验证码发送成功')
        }else{
          Toast.failToast(data.msg)
        }
      
    },
    * loginVerify({ payload }, {call, put, select }){
      const {data} = yield call(services.loginVerify, payload)
      console.log('invoke loginVerify')
      console.log(data)
      if(data.code=='0'){
        Toast.successToast('登录成功') 
        //保存用户数据
        var user=JSON.stringify(data.data);//将json对象转化成字符串
         localStorage.setItem("user",user);//把选择的数据存储在localstorage中
    
        yield put({
          type:'linkToUser',
          data
        })
      }else{
        Toast.failToast(data.msg)
      }
    },
    * quickLogin({ payload }, {call, put, select }){  
      　      const {data} = yield call(services.quickLogin, payload) 
      　      console.log(data) 
              if(data.code=='0'){
                Toast.successToast('登录成功') 
                //保存用户数据
                var user=JSON.stringify(data.data);//将json对象转化成字符串
                 localStorage.setItem("user",user);//把选择的数据存储在localstorage中
            
                yield put({
                  type:'linkToUser',
                  data
                })
              }else{
                Toast.failToast(data.msg)
              }
          },


    * userRegister({ payload }, {call, put, select }){  
　      const {data} = yield call(services.register, payload) 
　      console.log(data)
        console.log(data.code) 
        if(data.code=='0'){
          Toast.successToast('注册成功')
        }else{
          Toast.failToast(data.msg)
        }
    },
    
    * login({ payload }, {call, put, select }){  
　      const {data} = yield call(services.login, payload) 
　      console.log(data)
        console.log(data.code) 
        if(data.code=='0'){
          Toast.successToast('登录成功') 
          //保存用户数据
          var user=JSON.stringify(data.data);//将json对象转化成字符串
           localStorage.setItem("user",user);//把选择的数据存储在localstorage中
          
          //取数据如下
          // var test=localStorage.getItem("test");
          // if(test){
          //      var item=JSON.parse(test);
          //      console.log("id="+item.name+",name="+item.uid);
          //  }

          yield put({
            type:'linkToUser',
            data
          })
    
        }else{
          Toast.failToast(data.msg)
        }
    },

    * linkToUser({payload}, {put}) {
      console.log('linkToUser')
      // console.log(payload)//不知道为啥是undifined
      yield put(routerRedux.push({
        pathname: '/user',
        query: payload
      }));
    },



    * updateState({payload}, {call, put}) {
      for (let key in payload) {
        yield put({
          type: 'changeState',
          payload: {
            key: key,
            value: payload[key]
          }
        });
      }
    }
  },
  // 能改变界面的action应该放这里,这里按官方意思不应该做数据处理，只是用来return state 从而改变界面
  reducers: {
    // changeState可以理解为一个方法名 
    　　　　// 这里state就是上面初始的state，这里理解是旧state
    changeState(state, {payload}) {
      //return新的state,这样页面就会更新 es6语法，就是把state全部展开，然后把num:num重新赋值，
      // 这样后面赋值的num就会覆盖前面的。也是es6语法，相同名字可以写成一个，所以上面接收处写了num
      return {
        ...state,
        [[payload.key]]: payload.value
      };
    },
  },
};


