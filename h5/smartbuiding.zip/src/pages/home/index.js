import React, { Fragment } from 'react';
import { connect } from 'dva';
import styles from './index.css';
import { List } from 'antd-mobile';
import { InputItem } from 'antd-mobile';
import { Button } from 'antd-mobile';
import { Flex } from 'antd-mobile';

import Alert from 'components/alert/alert';
import Toast from 'components/alert/Toast';

class Home extends React.PureComponent {
  originbodyScrollY = document.getElementsByTagName('body')[0].style.overflowY;

  constructor(props) {
    super(props);
    this.state = {
      mobile: '',
      code: '',
      count: 60, // 秒数初始化为60秒
      codeSend: false // 还没有发送验证码
    };
  }

  componentDidMount() {
    this.loginVerfiy();
  }

  onMobileChange = mobile => {
    this.setState({
      mobile
    });
  };
  onVerifyChange = code => {
    this.setState({
      code
    });
  };

  //登录验证
  loginVerfiy = () => {
    this.props.dispatch({
      type: 'home/loginVerify'
    });
  };

  //发送验证码
  clickVerify = () => {
    // console.log(this.props)
    // Loading.Loading(true)
    // return
    // this.props.Layout(this,true)
    // return
    // codeSend is false 的时候，不允许再点击
    if (this.state.codeSend) {
      return;
    }
    if (this.state.mobile == null || this.state.mobile.length == 0) {
      Toast.showToast('请输入手机号');
      return;
    }
    console.log('发送验证码');

    let count = this.state.count;

    console.log(count);
    const timer = setInterval(() => {
      this.setState(
        {
          count: count--,
          codeSend: true
        },
        () => {
          if (count === 0) {
            clearInterval(timer);
            this.setState({
              codeSend: false,
              count: 60
            });
          }
        }
      );
    }, 1000);

    this.props.dispatch({
      type: 'home/fetchVerifyCode', // 这里就会触发models层里面effects中fetchVerifyCode方法（也可以直接触发reducer中方法，看具体情况） ,home就是models里的命名空间名字
      payload: {
        area: '86',
        phone: this.state.mobile,
        vtype: 'register'
      }
    });
  };

  //注册
  clickRegister = () => {
    console.log('注册');
    if (this.state.mobile == null || this.state.mobile.length == 0) {
      Toast.showToast('请输入手机号');
      return;
    }
    if (this.state.code == null || this.state.code.length == 0) {
      Toast.showToast('请输入验证码');
      return;
    }

    this.props.dispatch({
      type: 'home/userRegister',
      payload: {
        area: '86',
        phone: this.state.mobile,
        vcode: this.state.code,
        openid: 'oUFZVwr45t6bh78f0SXwBe6oVTRN'
      }
    });
    //  dispatch({
    //    type: 'home/linkToUser'
    //  })
  };

  //登录
  clickLogin = () => {
    if (this.state.mobile == null || this.state.mobile.length == 0) {
      Toast.showToast('请输入手机号');
      return;
    }

    if (this.state.code == null || this.state.code.length == 0) {
      Toast.showToast('请输入验证码');
      return;
    }
    this.props.dispatch({
      type: 'home/quickLogin',
      payload: {
        phone: this.state.mobile,
        vcode: this.state.code
      }
    });
    //  this.props. dispatch({
    //     type: "home/login",
    //     payload: {
    //       openid: 'oUFZVwr45t6bh78f0SXwBe6oVTRN'
    //     },
    //   })
  };
  //对话框
  showModal() {
    Alert.success({
      title: 'Modal',
      content: 'Hello World !',
      onCancel: () => {
        console.log('Cancel');
      },
      onOk: () => {
        console.log('Ok');
      }
    });
  }

  //toast
  showToast() {
    Toast.showToast();
  }

  //   <Button className={styles.button7} onClick={this.clickRegister}>
  //   绑定
  // </Button>

  // <Button className={styles.button7} onClick={this.showToast}>
  // test
  // </Button>
  /**
   * 渲染
   */
  render() {
    const { dispatch } = this.props;
    return (
      <div className={styles.div1}>
        <div className={styles.div2}>验证手机号查看订单</div>
        <div className={styles.div3}>
          <List className={styles.form4}>
            <InputItem
              className={styles.inputitem5}
              clear={false}
              type="number"
              placeholder="手机号"
              onChange={this.onMobileChange}
            />

            <Flex>
              <Flex.Item>
                <InputItem
                  className={styles.inputitemCode}
                  type="number"
                  placeholder="验证码"
                  onChange={this.onVerifyChange}
                />
              </Flex.Item>
              <Flex.Item>
                <Button
                  className={styles.buttonCode}
                  onClick={this.clickVerify}
                >
                  {!this.state.codeSend ? (
                    <span>获取验证码</span>
                  ) : (
                    <span>{this.state.count + 's'}</span>
                  )}
                </Button>
              </Flex.Item>
            </Flex>
          </List>

          <Button className={styles.button7} onClick={this.clickLogin}>
            登录
          </Button>
        </div>
      </div>
    );
  }
}

function mapStateToProps({ home }) {
  return Object.assign({}, home);
}

export default connect(mapStateToProps)(Home);
