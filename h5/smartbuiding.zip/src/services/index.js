import {
  get,
  post
} from '../utils/request';
import api from '../api';
import {
  async
} from 'q';

//获取验证码
export async function getCode(options) {
  console.log('getCode start')
  console.log(options)
  return post(api.formatAccountUrl('vcode'), options)
}

//登录验证
export async function loginVerify(options) {
  console.log('loginVerify start')
  // console.log(api.formatAccountUrl('loginVerify'))
  // console.log(options)
  return post(api.formatAccountUrl('loginVerify'), options)
}

//快捷登录
export async function quickLogin(options) {
  console.log('quickLogin start')
  console.log(options)
  return post(api.formatAccountUrl('quickLogin'), options)
}


//注册(暂时不用)
export async function register(options) {
  console.log('register start')
  console.log(options)
  return post(api.formatAccountUrl('register'), options)
}

//登录（暂时不用）
export async function login(options) {
  console.log('login start')
  console.log(options)
  return post(api.formatAccountUrl('validCheck'), options)
}

//获取订单列表
export async function getOrderList(options) {
  console.log('getOrderList start')
  // console.log(options)
  return post(api.formatUrl('wechat/orderlist'), options)
}

//获取订单详情
export async function getOrderDetail(options) {
  console.log('getOrderDetail start')
  console.log(options)
  return post(api.formatUrl('wechat/orderDetail'), options)
}

//开锁
export async function openLock(options) {
  console.log('openLock start')
  console.log(options)
  return post(api.formatUrl('device/unLock'), options)
}
