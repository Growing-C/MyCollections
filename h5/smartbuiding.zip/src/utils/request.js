import fetch from 'dva/fetch';
import isEmpty from 'lodash/isEmpty';

function checkStatus(response) {
  if (response.status >= 200 && response.status < 300) {
    const acckey = response.headers.get('acckey');
    const acctoken = response.headers.get('acctoken');
  
    if (!isEmpty(acckey) && !isEmpty(acctoken)) {
      localStorage.setItem('acckey', acckey);
      localStorage.setItem('acctoken', acctoken);
    }
    console.log(`response acckey ${acckey}`)
    console.log(`response acctoken ${acctoken}`)
    return response;
  }

  const error = new Error(response.statusText);
  error.response = response;
  throw error;
}

/**
 * Requests a URL, returning a promise.
 *
 * @param  {object} [options] The options we want to pass to "fetch"
 * {
   *   url: user,
   *   method: 'get',
   *   data: params,
   *   headers:{}
   * }
 * {
   *      method: 'POST',
   *      mode: 'cors',
   *      body:JSON.stringify(tubState),
   *      headers:myHeaders
   *}
 * @return {object}           An object containing either "data" or "err"
 */
export default async function request(options) {
  let headers = headers = {
    Accept: 'application/json',
    'Content-Type': 'application/json; charset=utf-8',
  };;
  const acckey = localStorage.getItem('acckey');
  const acctoken = localStorage.getItem('acctoken');

  if (!isEmpty(acckey) && !isEmpty(acctoken)) {
    headers.acctoken = acctoken;
    headers.acckey = acckey;
  
    console.log(`request accToken ${acctoken}`)
    console.log(`request acckey ${acckey}`)
  }

  // headers.language='zh'
  if (options.headers) {
    headers = Object.assign(headers, options.headers);
  }

  const url = options.url;
  const option = {
    method: options.method,
    mode: 'cors',
    body: options.params,
    headers: headers
  };

  const response = await fetch(url, option);

  checkStatus(response);

  const data = await response.json();

  return {
    data
  };
}

export function get(url, params = {}) {
  return request({
    url: url,
    method: 'get',
    params: params || {},
  });
}

export function post(url, params = {}) {
  return request({
    url: url,
    method: 'POST',
    // headers:{acctoken:'2222'},
    params: JSON.stringify(params || {}),
  });
}
