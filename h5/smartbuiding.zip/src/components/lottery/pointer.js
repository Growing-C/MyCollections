import React, { PureComponent } from 'react'
import classnames from 'classnames'
import styles from './index.less'
import LotteryDial from '../dial'

const attrprops = []
class Pointer extends PureComponent {

  static defaultStyles = () => {
    return {
      backgroundSize: '100%',
      position: 'absolute',
      top: '50%',
      left: '50%',
      display: 'block',
      width: '100px',
      height: '100px',
    }
  }

  constructor(props) {
    super(props)
    this.state = {
      id: "js_pointer" + Math.random()
    }
  }

  componentDidMount = () => {
    const lotteryDial = new LotteryDial(document.getElementById(this.state.id), {
      speed: 30, // 每帧速度
      areaNumber: 8 // 奖区数量
    })
    let index = -1
    lotteryDial.on('start', function() {
      // 请求获取中奖结果
      index = Math.round(Math.random() * 7)
      lotteryDial.setResult(index)
    //    // 假如请求出错
    //    setTimeout(function () {
    //      lottery.reset()
    //    }, 1000)
    })
    lotteryDial.on('end', function() {
      console.log('中奖奖区：' + index)
    })
    this.lotteryDial = lotteryDial
  }

  clickHandle = (e) => {
    const {className} = this.props
    if (!isEdit(className)) {
      e.stopPropagation();
      this.lotteryDial.draw()
    }
  }

  render() {
    const {id} = this.state
    const {className, dispatch, data, style, attr, children, ...otherProps} = this.props
    const _attr = JSON.parse(attr)
    const _style = JSON.parse(style)

    const speed = 30
    const number = 8

    if (this.lotteryDial) {
      this.lotteryDial.setOption({
        speed, // 每帧速度
        areaNumber: number, // 奖区数量
      })
    }

    return (
      <div id={ id } className={ classnames(className, styles.m_ui_dial, styles.pointer) } {...otherProps} style={ _style }>
        <a className={ styles.btn } href="javascript:;" onClick={ this.clickHandle }></a>
      </div>
    )
  }
}

export default Pointer
