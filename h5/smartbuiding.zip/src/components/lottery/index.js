import React, { PureComponent } from 'react'
import PropTypes from 'prop-types'
import classnames from 'classnames'
import styles from './index.less'
import LotteryDial from '../dial'
import Pointer from './pointer'

class Lottery extends PureComponent {

  static defaultStyles = () => {
    return {
      position: 'relative',
      width: '100%',
      height: '400px',
      margin: '0 auto',
      backgroundSize: '100%',
    };
  }

  static defaultChild = () => {
    return [{
      info: {
        type: '',
        dragType: 'Pointer',
        attr: [],
        events: [],
      },
      styles: Pointer.defaultStyles(),
      components: []
    }];
  }

  render() {
    const {className, dispatch, data, style, attr, children, ...otherProps} = this.props
    const _attr = JSON.parse(attr)
    const _style = JSON.parse(style)

    return (
      <div className={ classnames(className, styles.m_ui_dial) } {...otherProps} style={ _style }>
        { children }
      </div>
    )
  }
}

export default Lottery
