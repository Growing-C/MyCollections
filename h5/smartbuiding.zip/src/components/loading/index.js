import React from 'react';
import { ActivityIndicator } from 'antd-mobile';

function Loading({ isLoading }) { 
  return (<ActivityIndicator toasttext="Loading..." animating={isLoading} />);
}
export default Loading;
