import {
  Toast,
  WhiteSpace,
  WingBlank,
  Button
} from 'antd-mobile';

const showTimeLong= 1.5//toast显示时间

export default {
  dom: null, //被append的元素

  showToast(str) {
    if (str == null || str == undefined || str == '') {
      str = 'Load success !!!'
    }
    Toast.info(str, showTimeLong);
  },

  showToastNoMask() {
    Toast.info('Toast without mask !!!', showTimeLong, null, false);
  },

  successToast(str) {
    if (str == null || str == undefined || str == '') {
      str = 'Load success !!!'
    }
    Toast.success(str, showTimeLong);
  },
  failToast(str) {
    if (str == null || str == undefined || str == '') {
      str = 'Load failed !!!'
    }
    Toast.fail(str, showTimeLong);
  },

  offline() {
    Toast.offline('Network connection failed !!!', showTimeLong);
  },

  loadingToast() {
    Toast.loading('Loading...', showTimeLong, () => {
      console.log('Load complete !!!');
    });
  }
}
