/**
 * 定义接口
 * @type {{}}
 */
const api = {
  base_account_url: 'https://eco.blockchainlock.io/smartBuilding-account/wechat/user/', //默认的登录系统用的url
  base_url: 'https://eco.blockchainlock.io/smartBuilding-server/' //其他请求的base url
};




export default {

  //获取一般请求的路径
  formatUrl(path) {
    if (process.env.NODE_ENV == "development") {
      return api.base_url + path
    } else if (process.env.NODE_ENV == "production") {
      return api.base_url + path;
    }
  },

  //获取账号中心的url
  formatAccountUrl(path) {
    if (process.env.NODE_ENV == "development") {
      return api.base_account_url + path
    } else if (process.env.NODE_ENV == "production") {
      return api.base_account_url + path;
    }
  }

}
