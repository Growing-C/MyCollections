import { resolve } from "path";

export default {
  plugins: [
    ['umi-plugin-react', {
      dva: {
        immer: true,
      },
      antd: true,
      routes: {
        exclude: [/models\//],
      },
      targets: {
        chrome: 49,
        firefox: 45,
        safari: 10,
        edge: 13,
        ios: 10,
      },
      locale: {},
      library: 'react',
      dynamicImport: {
        webpackChunkName: true,
        // loadingComponent: './components/loading/index.js',
      },
      dll: {
        exclude: [],
      },
      hardSource: true,
      pwa: false,
      hd: false,
      fastClick: true,
      title: 'test',
    }],
  ],
  alias: {
    '@': resolve(__dirname, './src'),
    "utils": resolve(__dirname, "./src/utils"),
    "services": resolve(__dirname, "./src/services"),
    "components": resolve(__dirname, "./src/components"),
  },
  history: 'hash',
  base: './',
  publicPath: './',
};
